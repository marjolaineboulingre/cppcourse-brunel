var searchData=
[
  ['setextcurrent',['setExtCurrent',['../classNeuron.html#a3e56f4657cb679280db745045fd81774',1,'Neuron']]],
  ['setj',['setJ',['../classNeuron.html#a2cf5d64391bf740561760d93225cf8a1',1,'Neuron']]],
  ['setmembranepotential',['setMembranePotential',['../classNeuron.html#ab11bb27cf640e7e76a1a7647fc0a4259',1,'Neuron']]],
  ['setpoisson',['setPoisson',['../classNeuron.html#a011c2ed02a1a6c09b0c937c1ffc10449',1,'Neuron']]],
  ['simulation',['simulation',['../classNetwork.html#a3453f9910b1bb0f6857d55169692ffa5',1,'Network']]],
  ['simulation2neurons',['simulation2neurons',['../classNetwork.html#afb3f13b3ab42613e47da9b668593ed6b',1,'Network']]]
];
