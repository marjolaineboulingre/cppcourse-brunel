var searchData=
[
  ['isrefractory',['isRefractory',['../classNeuron.html#a93c77315f4f3ef66076843bfe272402e',1,'Neuron']]],
  ['isspiking',['isSpiking',['../classNeuron.html#af57ec66384fb1c6d6b0432f50287a38b',1,'Neuron']]]
];
