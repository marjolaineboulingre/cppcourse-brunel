var searchData=
[
  ['update',['update',['../classNetwork.html#a35394324d878dd7ad1227aaa4cdcc5c4',1,'Network::update()'],['../classNeuron.html#a09358a8fb1a85c46a035800966d435a3',1,'Neuron::update()']]],
  ['updatepotential',['updatePotential',['../classNeuron.html#ab521aac5bf7eb98555d0bb30ce7a4010',1,'Neuron']]]
];
